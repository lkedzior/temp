To release go to a server and run rfn command e.g.

rfn KdbConfig 125 UAT-P1-riverside1
rfn KdbConfig 125 PROD-P1-riverside2