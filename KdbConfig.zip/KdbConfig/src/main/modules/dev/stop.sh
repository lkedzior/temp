#This script specifies which processes should be stopped for this module (e.g tp/rdb/hdb)

stopApp hdb

stopApp rdb

stopApp tp
