#This script specifies which processes should be started for this module (e.g tp/rdb/hdb)

start_tp

start_rdb

start_hdb

