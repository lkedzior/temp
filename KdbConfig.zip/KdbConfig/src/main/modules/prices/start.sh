#This script specifies which processes should be started for this module (e.g tp/rdb/hdb)

start_tp

sleep 0.2

start_rdb

start_hdb


