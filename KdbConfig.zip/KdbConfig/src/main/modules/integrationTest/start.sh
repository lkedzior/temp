#This script specifies which processes should be started for this module (e.g tp/rdb/hdb)

#create custom hdb
#create a custom tpLog file
#start all processes e.g. tp, rdb, hdb, gw
#issue more .u.upd
#restart rdb
#check data has been replay
#send end of day
#restart with new .u.upd
#issue gw queries verify results

start_tp

sleep 0.2

start_rdb

start_hdb

start_hdbs

echo "sleeping 0.3"
sleep 0.3

start_gw

if [ $serverType == "secondary" ]; then start_secondary_hdb; fi


