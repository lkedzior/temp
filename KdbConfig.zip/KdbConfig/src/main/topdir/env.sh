echo "Loading $BASH_SOURCE"

#dependency on $HOME
export KDBAPPS_DIR=$HOME/apps

export KDBCONFIG_DIR=$KDBAPPS_DIR/KdbConfig/current
export TP_DIR=$KDBAPPS_DIR/tp/current
export RDB_DIR=$KDBAPPS_DIR/rdb/current
export HDB_DIR=$KDBAPPS_DIR/hdb/current
export GW_DIR=$KDBAPPS_DIR/gw/current
export QSCRIPTS_DIR=$KDBAPPS_DIR/qscripts/current

export USERS_FILE=$KDBAPPS_DIR/security/users.csv
export TP_USERS_FILE=$KDBAPPS_DIR/security/tp_users.csv

export LOGS_DIR=$HOME/stdout                #all application/stdout log files
export TP_LOGS_DIR=$HOME/tplogs             #root directory for tickerplant log file
export SYM_BACKUP_DIR=$HOME/sym_backup      #directory for backup of HDBs sym files
export DATA_DIR=/data01/$USER               #should we have symbolic link $HOME/data01?


export QHOME=~/q/  #location of bootstrap file q.k
export PATH=$PATH:$QHOME/l32

#export QLIC=$HOME/qlic
#Modules that use free q must unset QLIC
#If QLIC was defined then we were not able to start free version of kdb and had to unset QLIC
#unset QLIC

#export CPU_AFFINITY='taskset -c 3,5'
#export ONLOAD=onload  #use from hosts with Solarflare cards (see startup scripts)

source $KDBCONFIG_DIR/hostConfig.sh

alias kdbpm=$KDBCONFIG_DIR/kdbpm.sh
