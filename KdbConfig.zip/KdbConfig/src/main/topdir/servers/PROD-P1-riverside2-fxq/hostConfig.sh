echo "Loading $BASH_SOURCE"

export serverType=primary
#export thisHost=riverside1
#export remoteHost=riverside2