echo "Loading $BASH_SOURCE"

export serverType=secondary
#export thisHost=riverside2
#export remoteHost=riverside1