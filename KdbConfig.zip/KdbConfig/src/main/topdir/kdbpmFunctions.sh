#!/usr/bin/env bash

usage(){
  echo;
  echo "Usage:";
  echo;
  echo "m  [show all modules]";
  echo;
  echo "start_all";
  echo "stop_all";
  echo;
  echo "start_module module    e.g start_module integrationTest";
  echo "stop_module module";
  echo;
  echo "start_instance instance    e.g. start_instance 1030";
  echo "stop_instance instance";
  echo;
  echo "start_tp instance    e.g. start_tp 1030";
  echo "start_rdb instance";
  echo "start_hdb instance";
  echo "start_gw instance";
  echo "start_hdbs instance";
  echo "start_secondary_hdb instance";
  echo;
  echo "replay_tp_log instance yyyy.mm.dd    e.g. replay_tp_log 10010 2016.07.27";
  echo "replay_pricesWindows_log instance yyyy.mm.dd    e.g. replay_pricesWindows_log 10010 2016.07.27";
  echo;
  echo "backup_sym_all";

  echo "purge_hdb hdbDir noDaysToKeep"
  echo "purge_stdout_logs noDaysToKeep"
  echo "purge_tp_logs noDaysToKeep"

  echo "compress_tp_logs"
  echo "compress_file file"
  echo "decompress_file file"

  echo "reload_hdbPorts instance";    #used from eod
  echo "reload_remote_hdbs instance"; #used from eod

  echo "stdErrorReport minutes emailTo";

  echo "TODO copy_hdb_table_data copy_rdb_table_data(enrichedtradebackfill)";
  echo "TODO compress_date_partition, create_par_txt sync_hdb, reload_both_env"
  echo "missing from old ubs setup: reload_both_env, copy_table, sync hdb 5010 203.01.01, replay_tp_tables, load_tp_log, compress_date_partition 7010 2013.05.04"
}

mkdirp(){
  if [ ! -d $1 ]; then echo "creating $1"; mkdir -p $1; fi
}

make_directories(){
  for d in $LOGS_DIR $TP_LOGS_DIR $SYM_BACKUP_DIR $DATA_DIR; do mkdirp $d; done

  #remove current from path and create dir
  for d in $KDBCONFIG_DIR $TP_DIR $RDB_DIR $HDB_DIR $GW_DIR $QSCRIPTS_DIR; do mkdirp `dirname $d`; done
}

#init is used to initialise all variables used by kdbpm
#$1 - instance e.g. 1030
#instance is used in the tick.properties (see defaultTick.properties)
init(){
  if [ $# -ne 1 ]
    then
      echo "ERROR init requires instance";
      return;
  fi

  instance=$1;
  moduleName=${instanceMap[$instance]};
  moduleDir=$KDBCONFIG_DIR/modules/$moduleName
  now=`date +%Y-%m-%d-%H%M%S`;

  if test -f "$moduleDir/tick.properties"; then . $moduleDir/tick.properties;fi

  initFlag=true;
}

#must define the instanceMap outside function
#declare -A instanceMap
create_instance_map(){
  for f in $KDBCONFIG_DIR/modules/*/instancesPorts.properties
  do
    dirpath=`dirname $f`
    moduleName=${dirpath##*/}
    moduleDir=$KDBCONFIG_DIR/modules/$moduleName
    . $moduleDir/instancesPorts.properties

    for instance in $instances
    do
      instanceMap[$instance]=$moduleName
    done

  done
}

#Populate the $modules array
create_modules_list(){
  modules_all=()
  modules_before=()
  modules_after=()
  modules_other=()

  for dir in $KDBCONFIG_DIR/modules/*/
  do
    dirpath=${dir%*/}
    moduleName=${dirpath##*/}
    modules_all+=("$moduleName")
  done

  # add modulesBefore if they exist in modules_all (that's the case if given module is deployed to a server and appears in modules_all)
  for m in $modulesBefore
  do
    if [[ " ${modules_all[@]} " =~ " ${m} " ]]; then
      # whatever you want to do when arr contains value
      modules_before+=("$m")
    fi
  done

  for m in $modulesAfter
  do
    if [[ " ${modules_all[@]} " =~ " ${m} " ]]; then
      # whatever you want to do when arr contains value
      modules_after+=("$m")
    fi
  done

  #add remaining other modules to modules_all
  for m in "${modules_all[@]}"
  do
    if [[ ( ! " ${modules_before[@]} " =~ " ${m} " ) && ( ! " ${modules_after[@]} " =~ " ${m} " ) ]]; then
      modules_other+=("$m")
    fi
  done

  modules=("${modules_before[@]}" "${modules_other[@]}" "${modules_after[@]}")
  #modules_stop=("${modules_after[@]}" "${modules_other[@]}" "${modules_before[@]}")
}

#print all modules
m(){
  echo -e "\nKnown modules:";

  for m in "${modules[@]}"
  do
    echo $m
  done
}

#start all kdb processes
start_all(){
  echo -e "\nRunning start_all";

  echo "[start_all] modules_before=${modules_before[*]}"
  for m in "${modules_before[@]}"; do start_module $m; done
  sleep 1

  echo "[start_all] modules_other=${modules_other[*]}"
  for m in "${modules_other[@]}"; do start_module $m; done
  sleep 1

  echo "[start_all] modules_after=${modules_after[*]}"
  for m in "${modules_after[@]}"; do start_module $m; done
}

#stop all kdb processes
stop_all(){
  #todo use modules_stop
  echo -e "\nRunning stop_all";

  for dir in $KDBCONFIG_DIR/modules/*/
  do
    dirpath=${dir%*/}
    moduleName=${dirpath##*/}
    stop_module $moduleName
  done
}

#Takes module name and start all instances
start_module(){
  moduleName=$1
  moduleDir=$KDBCONFIG_DIR/modules/$moduleName

  #Load instanceIds
  . $moduleDir/instancesPorts.properties

  echo -e "\nStarting moduleName=$moduleName instances"

  for instance in $instances
  do
    echo "Starting instance=$instance"
    start_instance $instance
  done
}

#Takes module name and stop all module's instances
stop_module(){
  moduleName=$1
  moduleDir=$KDBCONFIG_DIR/modules/$moduleName

  #Load instanceIds
  . $moduleDir/instancesPorts.properties

  echo "Stopping moduleName=$moduleName instances"

  for instance in $instances
  do
    echo "Stopping instance=$instance"
    stop_instance $instance
  done
}

#Takes module and instance and start all processes
start_instance(){

  instance=$1;
  init $instance

  #it will call e.g. start_tp, start_rdb, start_hdb
  . $moduleDir/start.sh
}

#Takes instance and stop all instance's processes
stop_instance(){
  instance=$1;

  init $instance

  #it will call e.g. start_tp, start_rdb, start_hdb
  . $moduleDir/stop.sh
}

#$1 - instance (optional)
#may be called without $1 - see start.sh scripts
start_tp(){
  echo "[start_tp] BASHPID=$BASHPID"
  if [ -z "$initFlag" ]; then init $1; fi

  processId=tp-$tpPort
  stdoutLogFile=$LOGS_DIR/${processId}_$now.log

  . $KDBCONFIG_DIR/bin/start_tp.sh
}

#$1 - instance (optional)
#may be called without $1 - see start.sh scripts
start_rdb(){
  echo "[start_rdb] BASHPID=$BASHPID"
  if [ -z "$initFlag" ]; then init $1; fi

  processId=rdb-$rdbPort
  stdoutLogFile=$LOGS_DIR/${processId}_$now.log

  . $KDBCONFIG_DIR/bin/start_rdb.sh
}

#$1 - instance (optional)
#may be called without $1 - see start.sh scripts
start_hdb(){
  if [ -z "$initFlag" ]; then init $1; fi

  processId=hdb-$hdbPort
  stdoutLogFile=$LOGS_DIR/${processId}_$now.log

  if [ ! -d $hdbDir ]; then mkdir -p $hdbDir; fi

  . $KDBCONFIG_DIR/bin/start_hdb.sh
}

#$1 - instance
#Start all $hdbPorts HDBs
start_hdbs(){
  echo "[${FUNCNAME[0]}] BASHPID=$BASHPID";
  if [ -z "$initFlag" ]; then init $1; fi

  for port in $hdbPorts
  do
    hdbPort=$port
    start_hdb
  done
}

#TODO - add secondaryHdbDir and secondaryHdbPort to the default config
start_secondary_hdb(){
  echo "[${FUNCNAME[0]}] BASHPID=$BASHPID";
  if [ -z "$initFlag" ]; then init $1; fi

  hdbDirOld=$hdbDir
  hdbPortOld=$hdbPort
  hdbDir="${DATA_DIR}/modules/$moduleName/$instance/secondaryHdb"
  hdbPort=$secondaryHdbPort
  start_hdb
  hdbDir=$hdbDirOld
  hdbPort=$hdbPortOld
}

#$1 - instance (optional)
#may be called without $1 - see start.sh scripts
#todo start_tp start_rdb start_hdb start_gw can be replaced by one function
start_gw(){
  echo "Entering start_gateway BASHPID=$BASHPID"
  if [ -z "$initFlag" ]; then init $1; fi

  processId=gw-$gwPort
  stdoutLogFile=$LOGS_DIR/${processId}_$now.log

  . $KDBCONFIG_DIR/bin/start_gw.sh
}

#start q with core lib from qscripts
start_q(){
  kdbCoreLibDir=$QSCRIPTS_DIR/libs/KdbCoreLib
  export QINIT=$kdbCoreLibDir/loadQLIBPATH.q
  export QLIBPATH=""
  export QLIBPATH=$QLIBPATH::$kdbCoreLibDir/core
  export QLIBPATH=$QLIBPATH::$kdbCoreLibDir/core1
  $CPU_AFFINITY q $*
}

stop_hdbs(){
  echo "[${FUNCNAME[0]}] BASHPID=$BASHPID";
  if [ -z "$initFlag" ]; then init $1; fi

  for port in $hdbPorts
  do
    processId=hdb-$port
    stop_process $processId
  done

  if [ $serverType == "secondary" ]
    then
    processId=hdb-$secondaryHdbPort
    stop_process $processId
  fi
}

#takes application name to stop e.g. stop tp
stopApp(){
  if [ $# -ne 1 ]
    then
      echo "example usage: 'stopApp tp|rdb|hdb'";
      return;
  fi

  app=$1;
  portVarName=$app'Port'
  portValue=${!portVarName}
  processId=$app-$portValue

  stop_process $processId
}

#takes id of the process that should be stopped, e.g. stop_process rdb-10011
#will search for "processId rdb-10011" and stop it
stop_process(){
    if [ $# -ne 1 ]
    then
      echo "example usage: 'stop_process tp-10010";
      return;
  fi

  processId=$1
  echo -e "\nstopping processId=$processId"

  PROC_DETAILS=`ps xww | grep "processId $processId" | egrep -v "grep"`

  if [ 1 -eq `ps xww | grep "processId $processId" | egrep -v "grep" | wc -l` ]
  then
    echo "Stopping process: $PROC_DETAILS"
    PID=`echo $PROC_DETAILS | awk '{print $1}'`
    kill $PID
  else
    echo "WARN unexpected number of processes for $processId, process list=$PROC_DETAILS"
    return
  fi
}

replay_tp_log(){
  echo "Running replay_tp_log"
  instance=$1;
  date=$2
  init $instance
  tplog=$tpLogDir/${instance}tpLog$date
  start_q $QSCRIPTS_DIR/tplogreplay.q -schema $schemaFile -tplog $tplog -hdbdir $hdbDir -hdbpartition $date
}

replay_pricesWindows_log(){
  echo "Running replay_pricesWindows_log"
  instance=$1;
  date=$2
  init $instance
  tplog=$tpLogDir/prices$date
  start_q $QSCRIPTS_DIR/tplogreplay.q -schema $schemaFile -tplog $tplog -hdbdir $hdbDir -hdbpartition $date
}

backup_sym_all(){
  for dir in $KDBCONFIG_DIR/modules/*/
  do
    dirpath=${dir%*/}
    module=${dirpath##*/}
    echo "module=$module"

    moduleDir=$KDBCONFIG_DIR/modules/$module

    #Load instances property
    . $moduleDir/instancesPorts.properties
    for instance in $instances
    do
      echo "instance=$instance"
      init $instance
      backupSym
    done
  done
}

backupSym(){
  echo "copying $hdbDir/sym to $SYM_BACKUP_DIR/sym.$instance.$now"
  cp $hdbDir/sym $SYM_BACKUP_DIR/sym.$instance.$now
}

#$1 - hdbDir
#$2 - no of days
purge_hdb(){
  echo "Running ${FUNCNAME[0]}"

  if [ $# -ne 2 ]
  then
    echo "ERROR purge_hdb requires hdbDir noDays";
    exit 1;
  fi

  start_q $QSCRIPTS_DIR/purge_hdb.q -hdbDir $1 -noDays $2
}

#$1 number of days to keep
purge_tp_logs(){
  echo -e "\n[purge_tp_logs] Deleteing following files"
  find ${TP_LOGS_DIR}/ -type f -ctime +${1} -print
  find ${TP_LOGS_DIR}/ -type f -ctime +${1} -print | xargs rm;
}

purge_stdout_logs(){
  if [ $# -ne 1 ]
  then
    echo "ERROR example usage: 'purge_stdout_logs noDays'";
    exit 1;
  fi

  NODAYS=$1;

  echo -e "\n[purge_stdout_logs] Deleting following files"
  find${LOGS_DIR}/ -type f -ctime +$NODAYS -print
  echo -e "\nrunning find ${LOGS_DIR}/ -type f -ctime +$NODAYS -print | xargs rm"
  find ${LOGS_DIR}/ -type f -ctime +$NODAYS -print | xargs rm
}

compress_tp_logs(){
  YESTERDAY=`date --date="yesterday" +%Y.%m.%d -u`
  echo -e "\n[compress_tp_logs] Compressing following files"
  find ${TP_LOGS_DIR}/ -type f -name "*YESTERDAY"
  find ${TP_LOGS_DIR}/ -type f -name "*YESTERDAY" | xargs gzip
}

compress_file(){
  gzip $1
}

decompress_file(){
  gzip -d $1
}

#$1 - logs dir, make sure it ends with / e.g. $HOME/stdout/
#$2 - no of minutes for the find e.g. 60 -> find ... -mmin -60 -type f
#$3 - emailTo e.g. "lukasz.kedzior@....com"
stdErrorReport(){
  if [ $# -ne 2 ]
  then
    echo "ERROR stdErrorReport requires 'minutes' and 'emailTo' params";
    exit 1;
  fi

  start_q $QSCRIPTS_DIR/stderrorReport.q -stdoutDir ${1} -minutes ${2} -emailTo ${3}
}

#copy_hdb_table0 & copy_hdb_table

#copy_hdb_table
#copy_hdb_table0
#eod_rsync_push_and_reload
#rsync_push_hdb_partition_and_sym
#reload_hdbPorts
#reload_remote_hdbs
#reload_ports

sync_hdb(){
  PARTITION=$1
  HDBDIR=$hdbDir
  if [ $isPrimary == "true" ]; then
    echo "Running on Primary"
    REMOTE_HOST=$secondaryHost
  else
    echo "Running on Secondary"
    $REMOTE_HOST=$primaryHost
  fi

  echo "copying sym file"
  echo "cmd=rsync -ave ssh --delete --rsync-path=/usr/bin/rsync $HDBDIR/sym $REMOTE_HOST:$HDBDIR"
  rsync -ave ssh --delete --rsync-path=/usr/bin/rsync $HDBDIR/SYM $REMOTE_HOST:$HDBDIR

  echo "copying partition data"
  start_q $QSCRIPTS_DIR/sync_hdb.q -hdbDir $hdbDir -partition $PARTITION -remoteHost $REMOTE_HOST
}

# $1 noOfRestarts
# $2 skipExitCode
# $3 command to run
process_restart(){
(
  noOfRestarts=$1
  skipExitCode=$2
  command=$3

  counter=0

  until \
    $command; do
    exitCode=$?
    echo "[process_restart] $processId crashed with exit code $exitCode"
    echo "restart counter=$counter"
    if (( exitCode > $skipExitCode )); then
      echo "Aborting restart, exit code >= $skipExitCode"
      break
    fi

    if (( counter > $noOfRestarts )); then
      echo "Aborting restart, counter > $noOfRestarts"
      break
    fi

    ((counter++))

    sleep 5
  done
) 1>> $stdoutLogFile 2>&1 </dev/null &
}