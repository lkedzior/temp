#!/usr/bin/env bash

echo -e "\n`date` Running $BASH_SOURCE, PID=$$, BASHPID=$BASHPID"
echo "basename=`basename $0`, dirname=`dirname $0`"
echo "current dir=`pwd`"

basedir=`dirname $0`
. $basedir/env.sh
. $basedir/modulesOrder.sh
. $basedir/kdbpmFunctions.sh

declare -A instanceMap
create_instance_map
echo "Known instances"
for k in "${!instanceMap[@]}"; do echo "$k    ->    ${instanceMap[$k]}"; done

#create module array/list - will use this array order when starting with start_all
declare -a modules
create_modules_list
echo -e "\nModules list for start_all:"
echo "${modules[*]}"

set > $LOGS_DIR/set_$BASHPID.log

if [ $# -eq 0 ]
  then usage;
  exit 0;
fi

#call the function from the cmd line
#e.g. kdbpm.sh start_instance prices 10010 -> calls start_instace prices 10010
"$@"
