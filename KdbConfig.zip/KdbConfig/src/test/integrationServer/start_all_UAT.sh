#!/usr/bin/env bash

#Used from integration server jobs
#we can run below only once prod instances are moved away from riverside1
#ssh fxq@riverside1 "/home/fxq/apps/KdbConfig/current/kdbpm.sh start_all"

ssh fxq@riverside1 "/home/fxq/apps/KdbConfig/current/kdbpm.sh start_module dev"
ssh fxq@riverside1 "/home/fxq/apps/KdbConfig/current/kdbpm.sh start_module integrationTest"