#!/usr/bin/env bash

#Used from integration server jobs
ssh fxq@riverside1 "/home/fxq/apps/KdbConfig/current/kdbpm start_module integrationTest"