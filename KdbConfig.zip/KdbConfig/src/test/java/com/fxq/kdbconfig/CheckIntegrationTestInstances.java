package com.fxq.kdbconfig;

import com.fxq.kdb.connection.SimpleKdbConnection;
import kx.c;
import org.junit.Test;

import java.io.IOException;
import java.sql.Timestamp;

import static org.junit.Assert.assertArrayEquals;
import static org.junit.Assert.assertEquals;

//This test is not automatically run by the Surefire Plugin based on below name
//http://maven.apache.org/surefire/maven-surefire-plugin/examples/inclusion-exclusion.html
//To run it from command line mvn -Dtest=CheckIntegrationTestInstances test
//CI job runs this test http://riverside1:8080/view/Tests/job/IntegrationTest-Run/
public class CheckIntegrationTestInstances {

    String primaryServer = "riverside1";
    //String secondaryServer = "...";

    private void checkConnection(String host, int port) throws IOException, c.KException {
        System.out.println("Checking connection, host=" + host + ", port="+port);
        SimpleKdbConnection conn = new SimpleKdbConnection(new c(host, port));
        conn.sendSync("");
        conn.close();
    }

    @Test
    public void testConnection() throws IOException, c.KException {
        System.out.println("test 1030 integration test connections");
        int[] ports = new int[] {1030, 1031, 1032, 1033};
        for (int port : ports ) {
            checkConnection(primaryServer, port);
        }
    }

    @Test
    public void test1030Processes() throws IOException, c.KException, InterruptedException {
        System.out.println("Checking 1030 tp connection");
        SimpleKdbConnection tpConn = new SimpleKdbConnection(new c("riverside1", 1030));
        assertArrayEquals(new String[]{"testTable"}, (String[])tpConn.sendSync(".u.t"));

        System.out.println("Checking 1031 rdb connection");
        SimpleKdbConnection rdbConn = new SimpleKdbConnection(new c("riverside1", 1031));
        assertArrayEquals(new String[]{"testTable"}, (String[])rdbConn.sendSync(".u.t"));

        System.out.println("Checking 1032 hdb connection");
        SimpleKdbConnection hdbConn = new SimpleKdbConnection(new c("riverside1", 1032));
        assertEquals(Long.valueOf(2L), (Long)hdbConn.sendSync("2"));

        System.out.println("Checking 1033 gw connection");
        SimpleKdbConnection gwConn = new SimpleKdbConnection(new c("riverside1", 1033));
        assertEquals(Long.valueOf(2L), (Long)gwConn.sendSync("2"));

        System.out.println("Test module specific code has been loaded");
        assertEquals("testRdbSym", (String)rdbConn.sendSync(".rdb.module.lib.test"));
        assertEquals("testGwSym", (String)gwConn.sendSync(".gw.module.lib.test"));

        System.out.println("insert tp update");
        long now = System.currentTimeMillis();
        Timestamp publicTime = new Timestamp(now);
        tpConn.sendAsync(".u.upd", "testTable", new Object[]{"testSym", 10.0, 11.0, publicTime});

        System.out.println("check the update is in RDB");
        Thread.sleep(25);
        Object res = rdbConn.sendSync("{count select from testTable where publishTime=x}", publicTime);
        assertEquals(1L, res);

        System.out.println("run eod on RDB");
        rdbConn.sendSync(".u.end", new java.sql.Date(now));

        System.out.println("check update is in hdb");
        Object hdbRes = hdbConn.sendSync("{count select from testTable where date=.z.d, publishTime=x}", publicTime);
        assertEquals(1L, hdbRes);
    }

    @Test
    public void test1040Processes() throws IOException, c.KException {
        System.out.println("Checking 1040 tp connection");
        SimpleKdbConnection tpConn = new SimpleKdbConnection(new c("riverside1", 1040));
        assertArrayEquals(new String[]{"testTable"}, (String[])tpConn.sendSync(".u.t"));

        System.out.println("Checking 1041 rdb connection");
        SimpleKdbConnection rdbConn = new SimpleKdbConnection(new c("riverside1", 1041));
        assertArrayEquals(new String[]{"testTable"}, (String[])rdbConn.sendSync(".u.t"));

        System.out.println("Checking 1042 hdb connection");
        SimpleKdbConnection hdbConn = new SimpleKdbConnection(new c("riverside1", 1042));
        assertEquals(Long.valueOf(2L), (Long)hdbConn.sendSync("2"));

        System.out.println("Checking 1043 gw connection");
        SimpleKdbConnection gwConn = new SimpleKdbConnection(new c("riverside1", 1043));
        assertEquals(Long.valueOf(2L), (Long)gwConn.sendSync("2"));

        System.out.println("Test module specific code has been loaded");
        assertEquals("testGwSym", (String)gwConn.sendSync(".gw.module.lib.test"));
    }
}