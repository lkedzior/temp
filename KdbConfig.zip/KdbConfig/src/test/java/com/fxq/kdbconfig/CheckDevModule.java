package com.fxq.kdbconfig;

import com.fxq.kdb.connection.SimpleKdbConnection;
import kx.c;
import org.junit.*;

import java.io.IOException;

import static org.junit.Assert.assertEquals;

public class CheckDevModule {

    @BeforeClass
    public static void oneTimeSetUp() {
    }

    @AfterClass
    public static void oneTimeTearDown() {
    }

    @Before
    public void setUp() {
    }

    @After
    public void tearDown() {
    }

    @Test
    public void test1050Processes() throws IOException, c.KException {

        test1050Connections("riverside1");

        System.out.println("TODO Test module specific code has been loaded .e.g .sec.profiles");

    }

    private void test1050Connections(String host) throws IOException, c.KException {

        System.out.println("Checking 1050 tp connection");
        SimpleKdbConnection tpConn = new SimpleKdbConnection(new c(host, 1050));
        assertEquals(Long.valueOf(2L), (Long)tpConn.sendSync("2"));

        System.out.println("Checking 1051 rdb connection");
        SimpleKdbConnection rdbConn = new SimpleKdbConnection(new c(host, 1051));
        assertEquals(Long.valueOf(2L), (Long)rdbConn.sendSync("2"));

        System.out.println("Checking 1052 hdb connection");
        SimpleKdbConnection hdbConn = new SimpleKdbConnection(new c(host, 1052));
        assertEquals(Long.valueOf(2L), (Long)hdbConn.sendSync("2"));

        System.out.println("Checking 1053 gw connection");
        SimpleKdbConnection gwConn = new SimpleKdbConnection(new c(host, 1053));
        assertEquals(Long.valueOf(2L), (Long)gwConn.sendSync("2"));
    }


}