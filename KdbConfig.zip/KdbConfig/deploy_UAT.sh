#!/usr/bin/env bash

VERSION=0.1-SNAPSHOT

sh ../sdlc-utils/oldDeploy.sh fxq riverside1 target/KdbConfig-0.1-SNAPSHOT-UAT-P1-riverside1.tar.gz $VERSION KdbConfig
