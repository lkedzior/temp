#!/usr/bin/env bash

VERSION=0.1-SNAPSHOT
app=gw

sh ../sdlc-utils/oldDeploy.shfxq riverside1 target/$app-0.1-SNAPSHOT-dist.tar.gz $VERSION $app
