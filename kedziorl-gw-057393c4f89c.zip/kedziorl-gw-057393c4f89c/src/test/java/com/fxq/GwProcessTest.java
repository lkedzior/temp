package com.fxq;

import com.fxq.kdb.connection.SimpleKdbConnection;
import com.fxq.kdb.util.KdbProcess;
import kx.c;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;

import java.io.IOException;
import java.util.Arrays;

import static com.fxq.kdb.util.KdbProcess.QCMD;
import static org.junit.Assert.*;

public class GwProcessTest {

    String rdbPort="5001";
    String hdbPort="5002";
    String gwPort="5003";

    String QLIBPATH="target/KdbCoreLib/core::target/KdbCoreLib/core1";
    String QINIT="target/KdbCoreLib/loadQLIBPATH.q";


    String[] rdbCmd = new String[]{
            QCMD,
            "-p", rdbPort};
    String[] hdbCmd = new String[]{
            QCMD,
            "-p", hdbPort};

    String[] gwCmd = new String[]{
            QCMD, "src/main/q/gw.q",
            "-rdbHandle", "::"+rdbPort,
            "-hdbHandle", "::"+hdbPort,
            "-p", gwPort};


    @BeforeClass
    public static void setUpBeforeClass() throws Exception {
    }
    @AfterClass
    public static void tearDownAfterClass() throws Exception {
    }
    @Before
    public void setUp() throws Exception {
    }
    @After
    public void tearDown() throws Exception {
    }

    @org.junit.Test
    public void testStateAfterStartup() throws IOException, c.KException {

        System.out.println("Entering testStateAfterStartup");
        System.out.println("Working Directory = " +
                System.getProperty("user.dir"));

        SimpleKdbConnection rdbConn = null;
        SimpleKdbConnection hdbConn = null;
        SimpleKdbConnection gwConn = null;

        try{
            KdbProcess.startKdbProcess(rdbCmd,QINIT,QLIBPATH);
            Thread.sleep(100L);
            System.out.println("Rdb process started:" + Arrays.toString(rdbCmd));

            KdbProcess.startKdbProcess(hdbCmd,QINIT,QLIBPATH);
            Thread.sleep(100L);
            System.out.println("Hdb process started:" + Arrays.toString(hdbCmd));

            KdbProcess.startKdbProcess(gwCmd,QINIT,QLIBPATH);
            Thread.sleep(100L);
            System.out.println("Gw process started:" + Arrays.toString(gwCmd));

            rdbConn = new SimpleKdbConnection(new c("localhost", Integer.parseInt(rdbPort)));
            hdbConn = new SimpleKdbConnection(new c("localhost", Integer.parseInt(hdbPort)));
            gwConn = new SimpleKdbConnection(new c("localhost", Integer.parseInt(gwPort)));
            System.out.println("Gw connection created");

            assertTrue((Integer)gwConn.sendSync(".gs.rdb") > 0);
            assertTrue((Integer)gwConn.sendSync(".gs.hdb") > 0);

            System.out.println("Check handlers are connected to correct ports");
            assertEquals(Integer.parseInt(rdbPort), gwConn.sendSync(".gs.rdb\"\\\\p\""));
            assertEquals(Integer.parseInt(hdbPort), gwConn.sendSync(".gs.hdb\"\\\\p\""));


        } catch (Exception e) {
            System.out.println("ERROR: " + e);
            fail(e.toString());
        } finally {
            System.out.println("Entering finally");
            try{gwConn.sendSync("exit 0");} catch (IOException e) {/*ignore*/};
            try{rdbConn.sendSync("exit 0");} catch (IOException e) {/*ignore*/};
            try{hdbConn.sendSync("exit 0");} catch (IOException e) {/*ignore*/};
        }

        System.out.println("Exiting testStateAfterStartup");
    }
}
