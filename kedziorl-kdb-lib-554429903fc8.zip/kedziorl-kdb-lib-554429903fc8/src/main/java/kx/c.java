package kx; //jar cf c.jar kx/*.class

import java.io.DataInputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.io.PrintStream;
import java.io.UnsupportedEncodingException;
import java.lang.reflect.Array;
import java.net.ServerSocket;
import java.net.Socket;
import java.sql.Date;
import java.sql.Time;
import java.sql.Timestamp;
import java.text.DecimalFormat;
import java.util.UUID;
//tick: c c=new c("",5010);Object[]x={"GE",new Double(2.5),new Integer(23)};c.k(".u.upd","trade",x);
//Object[]x={new Time(t()),"xx",new Double(93.5),new Integer(300)};for(int i=0;i<1000;++i)c.ks("upsert","trade",x);c.k("");
//Flip t=td(c.k("select sum size by sym from trade"));O(n(t.x));O(n(t.y[0]));O(at(t.y[0],0)); //cols rows data

public class c {
	/*
	 * public static void main(String[]args){try{c c=new c("",5001); //
	 * O(c.k("0N!",c.k("0N!1999.01.01D-1"))); //c.k("0N!",NULL('z'));
	 * //c.setEncoding ("UTF-8");O("Unicode "+c.k("{`$x}","Ranby BjÃ¶rklund AB".
	 * toCharArray()));O("Unicode "+c.k("{x}",(String)c.k("{`$x}",(char[])c.k(
	 * "\"c\"$0x52616e627920426ac3b6726b6c756e64204142"))));
	 * c.close();}catch(Exception e){e.printStackTrace();}}
	 */

	private static String		e		= "ISO-8859-1";
	private static PrintStream	out		= System.out;
	private int					sync	= 0;

	public static void setEncoding(final String e)
			throws UnsupportedEncodingException {
		c.e = e;
		c.out = new PrintStream(System.out, true, e);
	}

	public Socket	s;
	DataInputStream	i;
	OutputStream	o;
	byte[]			b, B;
	int				j, J, vt;
	boolean			a;

	void io(final Socket x) throws IOException {
		this.s = x;
		this.i = new DataInputStream(this.s.getInputStream());
		this.o = this.s.getOutputStream();
	}

	public void close() throws IOException {
		if (null != this.s) {
			this.s.close();
			this.s = null;
		}
		;
		if (null != this.i) {
			this.i.close();
			this.i = null;
		}
		if (null != this.o) {
			this.o.close();
			this.o = null;
		}
	}

	public interface IAuthenticate {
		public boolean authenticate(String s);
	}

	public c(final ServerSocket s, final IAuthenticate a) throws IOException {
		this.io(s.accept());
		final int n = this.i.read(this.b = new byte[99]);
		if ((a != null)
				&& !a.authenticate(new String(this.b, 0, n > 1 ? n - 2 : 0))) {
			this.close();
			throw new IOException("access");
		}
		this.vt = n > 1 ? this.b[n - 2] : 0;
		this.b[0] = (byte) (this.vt < '\3' ? this.vt : '\3');
		this.o.write(this.b, 0, 1);
	} // c c=new c(new ServerSocket(5010));while(true)c.w(2,c.k());

	public c(final ServerSocket s) throws IOException {
		this(s, null);
	}

	public c(final String h, final int p, final String u) throws KException,
			IOException {
		this.B = new byte[2 + c.ns(u)];
		this.io(new Socket(h, p));
		this.J = 0;
		this.w(u + "\3");
		this.o.write(this.B);
		if (1 != this.i.read(this.B, 0, 1)) {
			this.close();
			this.B = new byte[1 + c.ns(u)];
			this.io(new Socket(h, p));
			this.J = 0;
			this.w(u);
			this.o.write(this.B);
			if (1 != this.i.read(this.B, 0, 1)) {
				this.close();
				throw new KException("access");
			}
		}
		this.vt = Math.min(this.B[0], 3);
	}

	public c(final String h, final int p) throws KException, IOException {
		this(h, p, System.getProperty("user.name"));
	}

	protected c() {
	};

	public static class Month implements Comparable<Month> {
		public int	i;

		public Month(final int x) {
			this.i = x;
		}

		@Override
		public String toString() {
			final int m = this.i + 24000, y = m / 12;
			return this.i == c.ni ? "" : c.i2(y / 100) + c.i2(y % 100) + "-"
					+ c.i2(1 + (m % 12));
		}

		@Override
		public boolean equals(final Object o) {
			return (o instanceof Month) ? ((Month) o).i == this.i : false;
		}

		@Override
		public int hashCode() {
			return this.i;
		}

		@Override
		public int compareTo(final Month m) {
			return this.i - m.i;
		}
	}

	public static class Minute implements Comparable<Minute> {
		public int	i;

		public Minute(final int x) {
			this.i = x;
		}

		@Override
		public String toString() {
			return this.i == c.ni ? "" : c.i2(this.i / 60) + ":"
					+ c.i2(this.i % 60);
		}

		@Override
		public boolean equals(final Object o) {
			return (o instanceof Minute) ? ((Minute) o).i == this.i : false;
		}

		@Override
		public int hashCode() {
			return this.i;
		}

		@Override
		public int compareTo(final Minute m) {
			return this.i - m.i;
		}
	}

	public static class Second implements Comparable<Second> {
		public int	i;

		public Second(final int x) {
			this.i = x;
		}

		@Override
		public String toString() {
			return this.i == c.ni ? "" : new Minute(this.i / 60).toString()
					+ ':' + c.i2(this.i % 60);
		}

		@Override
		public boolean equals(final Object o) {
			return (o instanceof Second) ? ((Second) o).i == this.i : false;
		}

		@Override
		public int hashCode() {
			return this.i;
		}

		@Override
		public int compareTo(final Second s) {
			return this.i - s.i;
		}
	}

	public static class Timespan implements Comparable<Timespan> {
		public long	j;

		public Timespan(final long x) {
			this.j = x;
		}

		@Override
		public String toString() {
			if (this.j == c.nj) {
				return "";
			}
			String s = this.j < 0 ? "-" : "";
			final long jj = this.j < 0 ? -this.j : this.j;
			final int d = ((int) (jj / 86400000000000L));
			if (d != 0) {
				s += d + "D";
			}
			return s + c.i2((int) ((jj % 86400000000000L) / 3600000000000L))
					+ ":" + c.i2((int) ((jj % 3600000000000L) / 60000000000L))
					+ ":" + c.i2((int) ((jj % 60000000000L) / 1000000000L))
					+ "." + c.i9((int) (jj % 1000000000L));
		}

		@Override
		public int compareTo(final Timespan t) {
			return this.j > t.j ? 1 : this.j < t.j ? -1 : 0;
		}

		@Override
		public boolean equals(final Object o) {
			return (o instanceof Timespan) ? ((Timespan) o).j == this.j : false;
		}

		@Override
		public int hashCode() {
			return (int) (this.j ^ (this.j >>> 32));
		}
	}

	public static class Dict {
		public Object	x;
		public Object	y;

		public Dict(final Object X, final Object Y) {
			this.x = X;
			this.y = Y;
		}
	}

	public static class Flip {
		public String[]	x;
		public Object[]	y;

		public Flip(final Dict X) {
			this.x = (String[]) X.x;
			this.y = (Object[]) X.y;
		}

		public Object at(final String s) {
			return this.y[c.find(this.x, s)];
		}
	}

	@SuppressWarnings("serial")
	public static class KException extends Exception {
		KException(final String s) {
			super(s);
		}
	}

	private void u() {
		int n = 0, r = 0, f = 0, s = 8, p = s;
		short i = 0;
		this.j = 0;
		final byte[] dst = new byte[this.ri()];
		int d = this.j;
		final int[] aa = new int[256];
		while (s < dst.length) {
			if (i == 0) {
				f = 0xff & this.b[d++];
				i = 1;
			}
			if ((f & i) != 0) {
				r = aa[0xff & this.b[d++]];
				dst[s++] = dst[r++];
				dst[s++] = dst[r++];
				n = 0xff & this.b[d++];
				for (int m = 0; m < n; m++) {
					dst[s + m] = dst[r + m];
				}
			} else {
				dst[s++] = this.b[d++];
			}
			while (p < (s - 1)) {
				aa[(0xff & dst[p]) ^ (0xff & dst[p + 1])] = p++;
			}
			if ((f & i) != 0) {
				p = s += n;
			}
			i *= 2;
			if (i == 256) {
				i = 0;
			}
		}
		this.b = dst;
		this.j = 8;
	}

	void w(final byte x) {
		this.B[this.J++] = x;
	}

	static int		ni	= Integer.MIN_VALUE;
	static long		nj	= Long.MIN_VALUE;
	static double	nf	= Double.NaN;

	boolean rb() {
		return 1 == this.b[this.j++];
	}

	void w(final boolean x) {
		this.w((byte) (x ? 1 : 0));
	}

	char rc() {
		return (char) (this.b[this.j++] & 0xff);
	}

	void w(final char c) {
		this.w((byte) c);
	}

	short rh() {
		final int x = this.b[this.j++], y = this.b[this.j++];
		return (short) (this.a ? (x & 0xff) | (y << 8) : (x << 8) | (y & 0xff));
	}

	void w(final short h) {
		this.w((byte) (h >> 8));
		this.w((byte) h);
	}

	int ri() {
		final int x = this.rh(), y = this.rh();
		return this.a ? (x & 0xffff) | (y << 16) : (x << 16) | (y & 0xffff);
	}

	void w(final int i) {
		this.w((short) (i >> 16));
		this.w((short) i);
	}

	UUID rg() {
		final boolean oa = this.a;
		this.a = false;
		final UUID g = new UUID(this.rj(), this.rj());
		this.a = oa;
		return g;
	}

	void w(final UUID uuid) {
		if (this.vt < 3) {
			throw new RuntimeException("Guid not valid pre kdb+3.0");
		}
		this.w(uuid.getMostSignificantBits());
		this.w(uuid.getLeastSignificantBits());
	}

	long rj() {
		final int x = this.ri(), y = this.ri();
		return this.a ? (x & 0xffffffffL) | ((long) y << 32) : ((long) x << 32)
				| (y & 0xffffffffL);
	}

	void w(final long j) {
		this.w((int) (j >> 32));
		this.w((int) j);
	}

	float re() {
		return Float.intBitsToFloat(this.ri());
	}

	void w(final float e) {
		this.w(Float.floatToIntBits(e));
	}

	double rf() {
		return Double.longBitsToDouble(this.rj());
	}

	void w(final double f) {
		this.w(Double.doubleToLongBits(f));
	}

	Month rm() {
		return new Month(this.ri());
	}

	void w(final Month m) {
		this.w(m.i);
	}

	Minute ru() {
		return new Minute(this.ri());
	}

	void w(final Minute u) {
		this.w(u.i);
	}

	Second rv() {
		return new Second(this.ri());
	}

	void w(final Second v) {
		this.w(v.i);
	}

	Timespan rn() {
		return new Timespan(this.rj());
	}

	void w(final Timespan n) {
		if (this.vt < 1) {
			throw new RuntimeException("Timespan not valid pre kdb+2.6");
		}
		this.w(n.j);
	}

	public java.util.TimeZone	tz	= java.util.TimeZone.getDefault();
	static long					k	= 86400000L * 10957, n = 1000000000L;

	long o(final long x) {
		return this.tz.getOffset(x);
	}

	long lg(final long x) {
		return x + this.o(x);
	}

	long gl(final long x) {
		return x - this.o(x - this.o(x));
	}

	Date rd() {
		final int i = this.ri();
		return new Date(i == c.ni ? c.nj : this.gl(c.k + (86400000L * i)));
	}

	void w(final Date d) {
		final long j = d.getTime();
		this.w(j == c.nj ? c.ni : (int) ((this.lg(j) / 86400000) - 10957));
	}

	Time rt() {
		final int i = this.ri();
		return new Time(i == c.ni ? c.nj : this.gl(i));
	}

	void w(final Time t) {
		final long j = t.getTime();
		this.w(j == c.nj ? c.ni : (int) (this.lg(j) % 86400000));
	}

	// Timestamp
	java.util.Date rz() {
		final double f = this.rf();
		return new java.util.Date(Double.isNaN(f) ? c.nj : this.gl(c.k
				+ Math.round(8.64e7 * f)));
	}

	void w(final java.util.Date z) {
		final long j = z.getTime();
		this.w(j == c.nj ? c.nf : (this.lg(j) - c.k) / 8.64e7);
	}

	Timestamp rp() {
		final long j = this.rj(), d = j < 0 ? ((j + 1) / c.n) - 1 : j / c.n;
		final Timestamp p = new Timestamp(j == c.nj ? j : this.gl(c.k
				+ (1000 * d)));
		if (j != c.nj) {
			p.setNanos((int) (j - (c.n * d)));
		}
		return p;
	}

	void w(final Timestamp p) {
		final long j = p.getTime();
		if (this.vt < 1) {
			throw new RuntimeException("Timestamp not valid pre kdb+2.6");
		}
		this.w(j == c.nj ? j : (1000000 * (this.lg(j) - c.k))
				+ (p.getNanos() % 1000000));
	}

	String rs() throws UnsupportedEncodingException {
		final int i = this.j;
		for (; this.b[this.j++] != 0;) {
			;
		}
		return (i == (this.j - 1)) ? "" : new String(this.b, i, this.j - 1 - i,
				c.e);
	}

	void w(final String s) throws UnsupportedEncodingException {
		int i = 0;
		final int n = c.ns(s);
		final byte[] b = s.getBytes(c.e);
		for (; i < n;) {
			this.w(b[i++]);
		}
		this.B[this.J++] = 0;
	}

	Object r() throws UnsupportedEncodingException {
		int i = 0, n;
		final int t = this.b[this.j++];
		if (t < 0) {
			switch (t) {
			case -1:
				return new Boolean(this.rb());
			case (-2):
				return this.rg();
			case -4:
				return new Byte(this.b[this.j++]);
			case -5:
				return new Short(this.rh());
			case -6:
				return new Integer(this.ri());
			case -7:
				return new Long(this.rj());
			case -8:
				return new Float(this.re());
			case -9:
				return new Double(this.rf());
			case -10:
				return new Character(this.rc());
			case -11:
				return this.rs();
			case -12:
				return this.rp();
			case -13:
				return this.rm();
			case -14:
				return this.rd();
			case -15:
				return this.rz();
			case -16:
				return this.rn();
			case -17:
				return this.ru();
			case -18:
				return this.rv();
			case -19:
				return this.rt();
			}
		}
		if (t > 99) {
			if (t == 100) {
				this.rs();
				return this.r();
			}
			if (t < 104) {
				return (this.b[this.j++] == 0) && (t == 101) ? null : "func";
			}
			if (t > 105) {
				this.r();
			} else {
				for (n = this.ri(); i < n; i++) {
					this.r();
				}
			}
			return "func";
		}
		if (t == 99) {
			return new Dict(this.r(), this.r());
		}
		this.j++;
		if (t == 98) {
			return new Flip((Dict) this.r());
		}
		n = this.ri();
		switch (t) {
		case 0:
			final Object[] L = new Object[n];
			for (; i < n; i++) {
				L[i] = this.r();
			}
			return L;
		case 1:
			final boolean[] B = new boolean[n];
			for (; i < n; i++) {
				B[i] = this.rb();
			}
			return B;
		case 2: {
			final UUID[] G = new UUID[n];
			for (; i < n; i++) {
				G[i] = this.rg();
			}
			return G;
		}
		case 4:
			final byte[] G = new byte[n];
			for (; i < n; i++) {
				G[i] = this.b[this.j++];
			}
			return G;
		case 5:
			final short[] H = new short[n];
			for (; i < n; i++) {
				H[i] = this.rh();
			}
			return H;
		case 6:
			final int[] I = new int[n];
			for (; i < n; i++) {
				I[i] = this.ri();
			}
			return I;
		case 7:
			final long[] J = new long[n];
			for (; i < n; i++) {
				J[i] = this.rj();
			}
			return J;
		case 8:
			final float[] E = new float[n];
			for (; i < n; i++) {
				E[i] = this.re();
			}
			return E;
		case 9:
			final double[] F = new double[n];
			for (; i < n; i++) {
				F[i] = this.rf();
			}
			return F;
		case 10:
			final char[] C = new String(this.b, this.j, n, c.e).toCharArray();
			this.j += n;
			return C;
		case 11:
			final String[] S = new String[n];
			for (; i < n; i++) {
				S[i] = this.rs();
			}
			return S;
		case 12:
			final Timestamp[] P = new Timestamp[n];
			for (; i < n; i++) {
				P[i] = this.rp();
			}
			return P;
		case 13:
			final Month[] M = new Month[n];
			for (; i < n; i++) {
				M[i] = this.rm();
			}
			return M;
		case 14:
			final Date[] D = new Date[n];
			for (; i < n; i++) {
				D[i] = this.rd();
			}
			return D;
		case 15:
			final java.util.Date[] Z = new java.util.Date[n];
			for (; i < n; i++) {
				Z[i] = this.rz();
			}
			return Z;
		case 16:
			final Timespan[] N = new Timespan[n];
			for (; i < n; i++) {
				N[i] = this.rn();
			}
			return N;
		case 17:
			final Minute[] U = new Minute[n];
			for (; i < n; i++) {
				U[i] = this.ru();
			}
			return U;
		case 18:
			final Second[] V = new Second[n];
			for (; i < n; i++) {
				V[i] = this.rv();
			}
			return V;
		case 19:
			final Time[] T = new Time[n];
			for (; i < n; i++) {
				T[i] = this.rt();
			}
			return T;
		}
		return null;
	}

	// object.getClass().isArray() t(int[]) is .5 isarray is .1 lookup .05
	public static int t(final Object x) {
		return x instanceof Boolean ? -1
			: x instanceof UUID ? -2
			: x instanceof Byte ? -4
			: x instanceof Short ? -5
			: x instanceof Integer ? -6
			: x instanceof Long ? -7
			: x instanceof Float ? -8
			: x instanceof Double ? -9
			: x instanceof Character ? -10
			: x instanceof String ? -11
			: x instanceof Date ? -14
			: x instanceof Time ? -19
			: x instanceof Timestamp ? -12
			: x instanceof java.util.Date ? -15
			: x instanceof Timespan ? -16
			: x instanceof Month ? -13
			: x instanceof Minute ? -17
			: x instanceof Second ? -18
			: x instanceof boolean[] ? 1
			: x instanceof UUID[] ? 2
			: x instanceof byte[] ? 4
			: x instanceof short[] ? 5
			: x instanceof int[] ? 6
			: x instanceof long[] ? 7
			: x instanceof float[] ? 8
			: x instanceof double[] ? 9
			: x instanceof char[] ? 10
			: x instanceof String[] ? 11
			: x instanceof Date[] ? 14
			: x instanceof Time[] ? 19
			: x instanceof Timestamp[] ? 12
			: x instanceof java.util.Date[] ? 15
			: x instanceof Timespan[] ? 16
			: x instanceof Month[] ? 13
			: x instanceof Minute[] ? 17
			: x instanceof Second[] ? 18
			: x instanceof Flip ? 98
			: x instanceof Dict ? 99
			: 0;
	}

	static int[]	nt	= { 0, 1, 16, 0, 1, 2, 4, 8, 4, 8, 1, 0, 8, 4, 4, 8, 8,
			4, 4, 4	};

	static int ns(String s) throws UnsupportedEncodingException {
		int i;
		if (s == null) {
			return 0;
		}
		if (-1 < (i = s.indexOf('\000'))) {
			s = s.substring(0, i);
		}
		return s.getBytes(c.e).length;
	}

	public static int n(final Object x) throws UnsupportedEncodingException {
		return x instanceof Dict ? c.n(((Dict) x).x) : x instanceof Flip ? c
				.n(((Flip) x).y[0]) : x instanceof char[] ? new String(
				(char[]) x).getBytes(c.e).length : Array.getLength(x);
	}

	public int nx(final Object x) throws UnsupportedEncodingException {
		int i = 0, n;
		final int t = c.t(x);
		int j;
		if (t == 99) {
			return 1 + this.nx(((Dict) x).x) + this.nx(((Dict) x).y);
		}
		if (t == 98) {
			return 3 + this.nx(((Flip) x).x) + this.nx(((Flip) x).y);
		}
		if (t < 0) {
			return t == -11 ? 2 + c.ns((String) x) : 1 + c.nt[-t];
		}
		j = 6;
		n = c.n(x);
		if ((t == 0) || (t == 11)) {
			for (; i < n; ++i) {
				j += t == 0 ? this.nx(((Object[]) x)[i]) : 1 + c
						.ns(((String[]) x)[i]);
			}
		} else {
			j += n * c.nt[t];
		}
		return j;
	}

	void w(final Object x) throws UnsupportedEncodingException {
		int i = 0, n;
		final int t = c.t(x);
		this.w((byte) t);
		if (t < 0) {
			switch (t) {
			case -1:
				this.w(((Boolean) x).booleanValue());
				return;
			case -2:
				this.w((UUID) x);
				return;
			case -4:
				this.w(((Byte) x).byteValue());
				return;
			case -5:
				this.w(((Short) x).shortValue());
				return;
			case -6:
				this.w(((Integer) x).intValue());
				return;
			case -7:
				this.w(((Long) x).longValue());
				return;
			case -8:
				this.w(((Float) x).floatValue());
				return;
			case -9:
				this.w(((Double) x).doubleValue());
				return;
			case -10:
				this.w(((Character) x).charValue());
				return;
			case -11:
				this.w((String) x);
				return;
			case -12:
				this.w((Timestamp) x);
				return;
			case -13:
				this.w((Month) x);
				return;
			case -14:
				this.w((Date) x);
				return;
			case -15:
				this.w((java.util.Date) x);
				return;
			case -16:
				this.w((Timespan) x);
				return;
			case -17:
				this.w((Minute) x);
				return;
			case -18:
				this.w((Second) x);
				return;
			case -19:
				this.w((Time) x);
				return;
			}
		}
		if (t == 99) {
			final Dict r = (Dict) x;
			this.w(r.x);
			this.w(r.y);
			return;
		}
		this.B[this.J++] = 0;
		if (t == 98) {
			final Flip r = (Flip) x;
			this.B[this.J++] = 99;
			this.w(r.x);
			this.w(r.y);
			return;
		}
		this.w(n = c.n(x));
		if (t == 10) {
			final byte[] b = new String((char[]) x).getBytes(c.e);
			for (; i < b.length;) {
				this.w(b[i++]);
			}
		} else {
			for (; i < n; ++i) {
				if (t == 0) {
					this.w(((Object[]) x)[i]);
				} else if (t == 1) {
					this.w(((boolean[]) x)[i]);
				} else if (t == 2) {
					this.w(((UUID[]) x)[i]);
				} else if (t == 4) {
					this.w(((byte[]) x)[i]);
				} else if (t == 5) {
					this.w(((short[]) x)[i]);
				} else if (t == 6) {
					this.w(((int[]) x)[i]);
				} else if (t == 7) {
					this.w(((long[]) x)[i]);
				} else if (t == 8) {
					this.w(((float[]) x)[i]);
				} else if (t == 9) {
					this.w(((double[]) x)[i]);
				} else if (t == 11) {
					this.w(((String[]) x)[i]);
				} else if (t == 12) {
					this.w(((Timestamp[]) x)[i]);
				} else if (t == 13) {
					this.w(((Month[]) x)[i]);
				} else if (t == 14) {
					this.w(((Date[]) x)[i]);
				} else if (t == 15) {
					this.w(((java.util.Date[]) x)[i]);
				} else if (t == 16) {
					this.w(((Timespan[]) x)[i]);
				} else if (t == 17) {
					this.w(((Minute[]) x)[i]);
				} else if (t == 18) {
					this.w(((Second[]) x)[i]);
				} else {
					this.w(((Time[]) x)[i]);
				}
			}
		}
	}

	protected void w(final int i, final Object x) throws IOException {
		final int n = this.nx(x) + 8;
		synchronized (this.o) {
			this.B = new byte[n];
			this.B[0] = 0;
			this.B[1] = (byte) i;
			this.J = 4;
			this.w(n);
			this.w(x);
			this.o.write(this.B);
		}
	}

	public void kr(final Object x) throws IOException {
		if (this.sync == 0) {
			throw new IOException("Unexpected response msg");
		}
		this.sync--;
		this.w(2, x);
	}

	public void ke(final String s) throws IOException {
		if (this.sync == 0) {
			throw new IOException("Unexpected error msg");
		}
		this.sync--;
		final int n = 2 + c.ns(s) + 8;
		synchronized (this.o) {
			this.B = new byte[n];
			this.B[0] = 0;
			this.B[1] = 2;
			this.J = 4;
			this.w(n);
			this.w((byte) -128);
			this.w(s);
			this.o.write(this.B);
		}
	}

	public void ks(final String s) throws IOException {
		this.w(0, this.cs(s));
	}

	public void ks(final Object x) throws IOException {
		this.w(0, x);
	}

	char[] cs(final String s) {
		return s.toCharArray();
	}

	public void ks(final String s, final Object x) throws IOException {
		final Object[] a = { this.cs(s), x };
		this.w(0, a);
	}

	public void ks(final String s, final Object x, final Object y)
			throws IOException {
		final Object[] a = { this.cs(s), x, y };
		this.w(0, a);
	}

	public void ks(final String s, final Object x, final Object y,
			final Object z) throws IOException {
		final Object[] a = { this.cs(s), x, y, z };
		this.w(0, a);
	}

	public Object k() throws KException, IOException,
			UnsupportedEncodingException {
		synchronized (this.i) {
			this.i.readFully(this.b = new byte[8]);
			this.a = this.b[0] == 1;
			if (this.b[1] == 1) {
				this.sync++;
			}
			final boolean c = this.b[2] == 1;
			this.j = 4;
			this.i.readFully(this.b = new byte[this.ri() - 8]);
			if (c) {
				this.u();
			} else {
				this.j = 0;
			}
			if (this.b[0] == -128) {
				this.j = 1;
				throw new KException(this.rs());
			}
			return this.r();
		}
	}

	public synchronized Object k(final Object x) throws KException, IOException {
		this.w(1, x);
		return this.k();
	}

	public Object k(final String s) throws KException, IOException {
		return this.k(this.cs(s));
	}

	public Object k(final String s, final Object x) throws KException,
			IOException {
		final Object[] a = { this.cs(s), x };
		return this.k(a);
	}

	public Object k(final String s, final Object x, final Object y)
			throws KException, IOException {
		final Object[] a = { this.cs(s), x, y };
		return this.k(a);
	}

	public Object k(final String s, final Object x, final Object y,
			final Object z) throws KException, IOException {
		final Object[] a = { this.cs(s), x, y, z };
		return this.k(a);
	}

	public static Object[]	NULL	= { null, new Boolean(false),
			new UUID(0, 0), null, new Byte((byte) 0),
			new Short(Short.MIN_VALUE), new Integer(c.ni), new Long(c.nj),
			new Float(c.nf), new Double(c.nf), new Character(' '), "",
			new Timestamp(c.nj), new Month(c.ni), new Date(c.nj),
			new java.util.Date(c.nj), new Timespan(c.nj), new Minute(c.ni),
			new Second(c.ni), new Time(c.nj) };

	public static Object NULL(final char c) {
		return NULL[" bg xhijefcspmdznuvt".indexOf(c)];
	}

	public static boolean qn(final Object x) {
		final int t = -c.t(x);
		return ((t == 2) || (t > 4)) && x.equals(c.NULL[t]);
	}

	public static Object at(Object x, final int i) {
		return c.qn(x = Array.get(x, i)) ? null : x;
	}

	public static void set(final Object x, final int i, final Object y) {
		Array.set(x, i, null == y ? c.NULL[c.t(x)] : y);
	}

	static int find(final String[] x, final String y) {
		int i = 0;
		for (; (i < x.length) && !x[i].equals(y);) {
			++i;
		}
		return i;
	}

	public static Flip td(final Object X)
			throws java.io.UnsupportedEncodingException {
		if (X instanceof Flip) {
			return (Flip) X;
		}
		final Dict d = (Dict) X;
		final Flip a = (Flip) d.x, b = (Flip) d.y;
		final int m = c.n(a.x), n = c.n(b.x);
		final String[] x = new String[m + n];
		System.arraycopy(a.x, 0, x, 0, m);
		System.arraycopy(b.x, 0, x, m, n);
		final Object[] y = new Object[m + n];
		System.arraycopy(a.y, 0, y, 0, m);
		System.arraycopy(b.y, 0, y, m, n);
		return new Flip(new Dict(x, y));
	}

	public static Object O(final Object x) {
		c.out.println(x);
		return x;
	}

	public static void O(final int x) {
		c.out.println(x);
	}

	public static void O(final boolean x) {
		c.out.println(x);
	}

	public static void O(final long x) {
		c.out.println(x);
	}

	public static void O(final double x) {
		c.out.println(x);
	}

	public static long t() {
		return System.currentTimeMillis();
	}

	static long	t;

	public static void tm() {
		final long u = c.t;
		c.t = c.t();
		if (u > 0) {
			c.O(c.t - u);
		}
	}

	static String i2(final int i) {
		return new DecimalFormat("00").format(i);
	}

	static String i9(final int i) {
		return new DecimalFormat("000000000").format(i);
	}
}
// 2013.12.19 qn did not detect null guid
// 2013.05.01 added compareTo() to temporal classes, timespan.toString(), kr, ke
// 2013.04.29 added hashCode() to temporal classes
// 2013.04.22 added x instanceof UUID[]?:
// 2012.05.29 for use with kdb+v3.0, changed handshake and added UUID. boolean
// v6->vt reflects type version
// 2012.03.01 added equals() for Month,Minute,Second,Timespan. null checks in
// close().
// empty constructor c() and changed w(int,Object) to protected
// 2012.02.09 close() if connect fails
// 2012.01.06 read datetime, rz(), was truncating mS rather than rounding
// 2010.10.06 block sending timestamp/timespan types to versions prior to
// kdb+2.6
// 2010.05.06 optimized rs() for reading null symbols
// 2010.03.20 changed datetime to java.util.Date as it was incompatible with
// timestamp
// 2010.02.01 added unicode support for char vectors and symbol
// 2010.01.06 fixed 0Np
// 2009.12.07 removed v6 dependencies
// 2009.12.02 uncommented at, set and qn
// 2009.10.29 u - uncompress, connect retry for v<=2.5
// 2009.09.23 Timestamp,Timespan,v6 connect
// 2008.08.14 String(,,,"ISO-8859-1") to avoid mutex
// 2007.10.18 tz
// 2007.08.06 kx
// 2007.04.20 sql.{Date|Time|Timestamp}
