package com.fxq.kdb;

import com.fxq.kdb.connection.KdbConnection;
import kx.c;

import java.io.IOException;

/**
 * Created by Lukasz on 16/07/2017.
 *
 * Instance of this class is only created in the KdbSubscriber
 * We may want to change this class to be inner class within the Subcriber
 *
 */
public class KdbListenerRunnable implements Runnable {

    private final KdbConnection kdbConnection;
    private final UpdHandler updHandler;

    public KdbListenerRunnable(KdbConnection kdbConnection, UpdHandler updHandler) {
        this.kdbConnection = kdbConnection;
        this.updHandler = updHandler;
    }

    @Override
    public void run() {
        while(true) {
            try {
                Object o = this.kdbConnection.listen();
                this.updHandler.handle(o);
            } catch (IOException e) {
                this.updHandler.handleException(e);
            } catch (c.KException e) {
                this.updHandler.handleException(e);
            }
        }
    }
}
