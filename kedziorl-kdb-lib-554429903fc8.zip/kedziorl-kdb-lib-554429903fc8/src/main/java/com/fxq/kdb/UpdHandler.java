package com.fxq.kdb;

/**
 * Created by Lukasz on 16/07/2017.
 */
public interface UpdHandler {

    void handle(Object o);
    void handleException(Exception e);
}
