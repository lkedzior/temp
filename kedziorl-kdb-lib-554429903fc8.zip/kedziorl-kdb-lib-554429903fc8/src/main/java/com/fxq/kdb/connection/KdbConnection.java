package com.fxq.kdb.connection;

import java.io.IOException;

import kx.c.KException;

public interface KdbConnection
{

	public Object sendSync(String s) throws KException, IOException;

	public Object sendSync(String s, Object x) throws KException, IOException;

	public Object sendSync(String s, Object x, Object y) throws KException, IOException;

	public Object sendSync(String s, Object x, Object y, Object z) throws KException, IOException;

	public void sendAsync(String s) throws IOException;

	public void sendAsync(String s, Object x) throws IOException;

	public void sendAsync(String s, Object x, Object y) throws IOException;

	public void sendAsync(String s, Object x, Object y, Object z) throws IOException;

	public Object listen() throws IOException, KException;

    public void close() throws IOException;
}
