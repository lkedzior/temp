package com.fxq.kdb.util;

import java.io.IOException;
import java.util.Arrays;

import static java.lang.System.out;

/**
 * Created by Lukasz on 21/08/2017.
 */
public class KdbProcess {

    public static String QCMD="q";
    static {
        String startKdbCmd = System.getProperty("startKdbCmd");
        if(startKdbCmd != null) {QCMD=startKdbCmd;};
    }

    public static Process startKdbProcess(String[] cmd, String QINIT, String QLIBPATH) throws IOException {
        ProcessBuilder kdbProcess = new ProcessBuilder(cmd);
        kdbProcess.redirectOutput(ProcessBuilder.Redirect.INHERIT);
        kdbProcess.redirectError(ProcessBuilder.Redirect.INHERIT);
        //kdbProcess.redirectErrorStream(true);
        kdbProcess.redirectInput(ProcessBuilder.Redirect.INHERIT);

        if(!"".equals(QINIT)){kdbProcess.environment().put("QINIT",QINIT);};
        if(!"".equals(QLIBPATH)){kdbProcess.environment().put("QLIBPATH",QLIBPATH);};
        Process p = kdbProcess.start();
        return p;
    }

    public static int runQspec() throws IOException, InterruptedException {
        String QLIBPATH = "target/KdbCoreLib/core"
                +"::target/KdbCoreLib/core1"
                +"::target/qspecLib/init.q";

        String QINIT= "target/KdbCoreLib/loadQLIBPATH.q";

        String QSPEC_TESTS_DIR = "src/test/qspec";

        return runQspec(QLIBPATH, QINIT, QSPEC_TESTS_DIR);
    }

    public static int runQspec(String qlibpath, String qinit, String qpsecTestsDir) throws IOException, InterruptedException {
        String[] qspecCmd = new String[]{
                QCMD,
                "target/qspecLib/spec.q",
                "-q",
                qpsecTestsDir};

        out.println("Starting qspec process:" + Arrays.toString(qspecCmd));

        Process p = startKdbProcess(qspecCmd, qinit, qlibpath);
        p.waitFor();

        int exitValue = p.exitValue();
        out.println("qspecProcess exitValue=" + exitValue);
        return exitValue;
    }

    public static int runQspecFailHard() throws InterruptedException, IOException {
        String QLIBPATH = "target/KdbCoreLib/core"
                +"::target/KdbCoreLib/core1"
                +"::target/qspecLib/init.q";
        String QINIT= "target/KdbCoreLib/loadQLIBPATH.q";
        String QSPEC_TESTS_DIR = "src/test/qspec";

        String[] qspecCmd = new String[]{
                QCMD,
                "target/qspecLib/spec.q",
                "-q",
                QSPEC_TESTS_DIR,
                "--fail-hard"};

        Process p = startKdbProcess(qspecCmd, QINIT, QLIBPATH);
        p.waitFor();

        int exitValue = p.exitValue();
        out.println("qspecProcess exitValue=" + exitValue);
        return exitValue;
    }

}
