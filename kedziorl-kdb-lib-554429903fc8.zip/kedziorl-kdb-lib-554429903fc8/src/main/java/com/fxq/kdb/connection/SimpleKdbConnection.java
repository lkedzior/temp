package com.fxq.kdb.connection;

import java.io.IOException;

import kx.c;
import kx.c.KException;

public class SimpleKdbConnection implements KdbConnection
{

	private final c	conn;

	public SimpleKdbConnection(final c conn)
	{
		this.conn = conn;
	}

	@Override
	public Object sendSync(final String s) throws KException, IOException
	{
		return this.conn.k(s);
	}

	@Override
	public Object sendSync(final String s, final Object x) throws KException, IOException
	{
		return this.conn.k(s, x);
	}

	@Override
	public Object sendSync(final String s, final Object x, final Object y) throws KException,
			IOException
	{
		return this.conn.k(s, x, y);
	}

	@Override
	public Object sendSync(final String s, final Object x, final Object y, final Object z)
			throws KException, IOException
	{
		return this.conn.k(s, x, y, z);
	}

	@Override
	public void sendAsync(final String s) throws IOException
	{
		this.conn.ks(s);
	}

	@Override
	public void sendAsync(final String s, final Object x) throws IOException
	{
		this.conn.ks(s, x);
	}

	@Override
	public void sendAsync(final String s, final Object x, final Object y) throws IOException
	{
		this.conn.ks(s, x, y);
	}

	@Override
	public void sendAsync(final String s, final Object x, final Object y, final Object z)
			throws IOException
	{
		this.conn.ks(s, x, y, z);
	}

	@Override
	public Object listen() throws IOException, KException {
		return this.conn.k();
	}

    @Override
    public void close() throws IOException {
         this.conn.close();
    }

}
