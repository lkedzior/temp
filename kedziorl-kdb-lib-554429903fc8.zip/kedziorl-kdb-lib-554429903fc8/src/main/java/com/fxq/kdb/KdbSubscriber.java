package com.fxq.kdb;

import com.fxq.kdb.connection.KdbConnection;
import kx.c;

import java.io.IOException;

/**
 * Created by Lukasz on 16/07/2017.
 */
public class KdbSubscriber {

    private final KdbConnection kdbConnection;
    private final String subFunc;       //defaults to ".u.sub"
    private final String subTable;      //defaults to "" (all tables)
    private final Object subSymList;    //defaults to "" (can also be String[]{"sym1";"sym2";...}
    private final Runnable runnable;
    private final Thread.UncaughtExceptionHandler ueh;

    public KdbSubscriber(KdbConnection kdbConnection, String subFunc, String subTable, Object subSymList, Runnable runnable, Thread.UncaughtExceptionHandler ueh) {
        this.kdbConnection = kdbConnection;
        this.subFunc = subFunc;
        this.subTable = subTable;
        this.subSymList = subSymList;
        this.runnable = runnable;
        this.ueh = ueh;
    }

    public static KdbSubscriber newDefaultInstance(KdbConnection kdbConnection, UpdHandler kdbUpdateHandler, Thread.UncaughtExceptionHandler ueh){
        return new KdbSubscriber(kdbConnection, ".u.sub", "", "", new KdbListenerRunnable(kdbConnection, kdbUpdateHandler), ueh);
    }

//    public static void defaultInit(KdbConnection kdbConnection, UpdHandler kdbUpdateHandler) throws IOException, c.KException {
//        KdbSubscriber subscriber = new KdbSubscriber(kdbConnection, ".u.sub", "", "", new KdbListenerRunnable(kdbConnection, kdbUpdateHandler));
//        subscriber.subscribe();
//        subscriber.startListenerThread();
//    }

    public Object subscribe() throws IOException, c.KException {
        Object subFuncResults = this.kdbConnection.sendSync(this.subFunc, this.subTable, this.subSymList);
        return subFuncResults;
    }

    public void startListenerThread() {
        Thread thread = new Thread(this.runnable);
        thread.setUncaughtExceptionHandler(this.ueh);
        thread.setName("KdbSubscriberThread");
        thread.start();
    }
}
