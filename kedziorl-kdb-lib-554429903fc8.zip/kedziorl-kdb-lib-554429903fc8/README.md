# README #

This is a java library with classes that provide implementations for
Kdb Connections and Queries


### What is this repository for? ###

* Quick summary
* Version
* [Learn Markdown](https://bitbucket.org/tutorials/markdowndemo)

### How do I get set up? ###

* Summary of set up
* Configuration
* Dependencies
* Database configuration
* How to run tests
* Deployment instructions

### Contribution guidelines ###

* Writing tests
* Code review
* Other guidelines

### Who do I talk to? ###

* Repo owner or admin
* Other community or team contact

### Checking out the code ###

```
F:\git\private>git clone https://kedziorl@bitbucket.org/kedziorl/kdb-lib.git
Cloning into 'kdb-lib'...
Password for 'https://kedziorl@bitbucket.org':
remote: Counting objects: 22, done.
remote: Compressing objects: 100% (11/11), done.
remote: Total 22 (delta 2), reused 0 (delta 0)
Unpacking objects: 100% (22/22), done.
Checking connectivity... done.

F:\git\private>
```

### Build and release ###

Currently manual build & release
Change pom.xml version to full version e.g. 0.7
Start the terminal run mvn clean deploy
Update pom.xml to next SNAPSHOT e.g. <version>0.8-SNAPSHOT</version>
