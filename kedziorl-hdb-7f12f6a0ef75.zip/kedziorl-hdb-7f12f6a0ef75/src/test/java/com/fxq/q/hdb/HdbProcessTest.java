package com.fxq.q.hdb;

import com.fxq.kdb.connection.SimpleKdbConnection;
import com.fxq.kdb.util.KdbProcess;
import kx.c;

import java.io.IOException;
import java.util.Arrays;

import static org.junit.Assert.assertArrayEquals;
import static org.junit.Assert.fail;

/**
 * Created by Lukasz on 22/05/2016.
 */
public class HdbProcessTest{

    String hdbPort="5000";

    String QLIBPATH = "target/KdbCoreLib/core::target/KdbCoreLib/core1";
    String QINIT = "target/KdbCoreLib/loadQLIBPATH.q";

    String[] hdbCmd = new String[]{
            "q", "src/main/q/hdb.q",
            "-hdbDir", "src/test/testData/hdbDir",
            "-p", hdbPort};


    @org.junit.Test
    public void testStateAfterStartup() throws IOException, c.KException {

        System.out.println("Entering testStateAfterStartup");

        SimpleKdbConnection hdbConn = null;

        try{
            KdbProcess.startKdbProcess(hdbCmd,QINIT,QLIBPATH);
            //On Linux we get connection refused if we don't wait
            Thread.sleep(100L);
            System.out.println("Hdb process started:" + Arrays.toString(hdbCmd));

            hdbConn = new SimpleKdbConnection(new c("localhost", Integer.parseInt(hdbPort)));
            System.out.println("Hdb connection created");

            System.out.println("Check data from hdbDir has been loaded");
            assertArrayEquals(new long[]{1, 2, 3}, (long[])hdbConn.sendSync("testList"));

            System.out.println("Finished asserting");

        } catch (Exception e) {
            System.out.println("ERROR: " + e);
            fail(e.toString());
        } finally {
            System.out.println("Entering finally");
            try{
                hdbConn.sendSync("exit 0");
            } catch (IOException e) {
                //ignore
            }
        }

        System.out.println("Exiting testStateAfterStartup");

    }
}
