#usage
#cd /cygdrive/d/repos/bitbucket
#cp sdlc-utils/clone_all.sh .
#sh clone_all.sh

function kedziorlBitbucketCloneIfNotPresent(){
  repoName=$1
  if [ ! -d $repoName ] ; then git clone git@bitbucket.org:kedziorl/${repoName}.git $repoName;
  else  echo "$repoName already exists"
fi
}

allRepositories='KdbConfig rdb rsiCalc KdbCoreLib sdlc-utils tp qscripts gw hdb oandaPricesFeedHandler kdb-lib oandaTrader-app qspecLib oandaTransFeedHandler-app oanda-examples java-parent-pom kdb-parent-pom sdlc-mvn-assembly mavenSpringSampleProject oandapricesfeedhandlerv20'
for repoName in $allRepositories; do
  kedziorlBitbucketCloneIfNotPresent $repoName
done
