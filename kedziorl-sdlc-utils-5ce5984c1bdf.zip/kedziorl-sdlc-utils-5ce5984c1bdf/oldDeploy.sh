#!/usr/bin/env bash

set -e

user=$1
hostname=$2
artifactPath=$3
artifact=$(basename $artifactPath)
version=$4
app=$5

dstdir=/home/fxq/apps/$app

echo "scp the file $artifactPath $dstdir"
scp $artifactPath $user@hostname:$dstdir

echo "chmod 755 $dstdir/$artifact"
ssh $user@$hostname chmod 755 $dstdir/$artifact

appDst=$dstdir/$app-$version
echo "appDst=$appDst"
#delete installation if already exists (useful when re-deploying same snapshot version)
ssh $user@$hostname "if [ -d $appDst ]; then rm -r $appDst; fi"

echo "creating appDst=$appDst such that the tar --directory option works"
ssh $user@$hostname mkdir -p $appDst

echo "Running tar zxvf $dstdir/$artifact --directory $appDst"
ssh $user@$hostname tar zxvf $dstdir/$artifact --directory $appDst

ssh $user@$hostname  ln -sfn $appDst $dstdir/current

echo "Installation complete"

ssh $user@$hostname "hostname -f;ls -lrtha $dstdir"


