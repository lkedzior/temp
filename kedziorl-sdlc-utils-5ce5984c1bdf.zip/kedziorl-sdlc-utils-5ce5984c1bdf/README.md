**Setting up dev environment**

Checkout all the projects using the clone all script

1) Download maven e.g. D:/DevPrograms/apache-maven-3.3.9
Update Maven Home directory in Intellij settings and point it to D:/DevPrograms/apache-maven-3.3.9
Copy the sdlc-utils/mvnSettings.xml to user .m2 e.g. C:\Users\Lukasz\.m2, update <localRepository> tag
