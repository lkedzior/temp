#!/usr/bin/env bash

/bin/taskset -c 3,5 $QHOME/q $*
