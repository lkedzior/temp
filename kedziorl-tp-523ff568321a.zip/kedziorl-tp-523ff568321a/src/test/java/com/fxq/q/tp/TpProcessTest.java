/**
 * 
 */
package com.fxq.q.tp;

import com.fxq.kdb.connection.SimpleKdbConnection;
import com.fxq.kdb.util.KdbProcess;
import kx.c;
import kx.c.KException;
import org.apache.commons.io.FileUtils;
import org.junit.Test;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Date;

import static org.junit.Assert.*;

/**
 * @author Lukasz
 *
 */
public class TpProcessTest {
	
	String tmpPath="tmp";
	String port="4999";
	
	String[] cmd = new String[]{
			"q", "src/main/q/tick.q",
			"-schemaFile", "src/test/q/testData/schema.q",
			"-tpLogDir", tmpPath,
			"-p", port};

	@Test
	public void testStateAfterStartup() throws IOException, KException {
		
		System.out.println("Entering testStateAfterStartup");

		File tmpDir = new File(tmpPath);
		if (!tmpDir.exists()) {
			tmpDir.mkdir();
		} else {
			System.out.println("Deleting tmpDir="+tmpDir);
			FileUtils.deleteDirectory(tmpDir);
		}

		SimpleKdbConnection conn = null;

		try{
			KdbProcess.startKdbProcess(cmd,"","");
			//On Linux we get connection refused if we don't wait 
			Thread.sleep(100L);
			System.out.println("Process started:" + Arrays.toString(cmd));
			
			conn = new SimpleKdbConnection(new c("localhost", Integer.parseInt(port)));
			System.out.println("Connection created");
			
			//check .u.t - table names
			assertArrayEquals(new String[]{"mytable"}, (String[])conn.sendSync(".u.t"));

			//check .u.i - msg count
			assertEquals(0L, conn.sendSync(".u.i"));
			
			//check .u.d - current date
			String dt =  new SimpleDateFormat("yyyy.MM.dd").format(new Date());
			assertEquals(dt, conn.sendSync("`$string .u.d"));
			
			//check .u.L - tp log filename e.g. :tmp/5000tpLog2016.04.16
			assertEquals(":"+tmpPath+"/"+port+"tpLog"+dt, conn.sendSync(".u.L"));
			
			//check .u.l - tp log file handle
			Integer ul = (Integer)conn.sendSync(".u.l");
			assertTrue(ul>0);
			
			//check .u.w dictionary of tables - > list of (handle;syms)
			kx.c.Dict uw = (kx.c.Dict)conn.sendSync(".u.w");
			assertArrayEquals(new String[]{"mytable"}, (String[])uw.x);
			Object[]uwy = (Object[])uw.y;
			Object[]mytableSubscribers = (Object[])uwy[0];
			assertArrayEquals(mytableSubscribers, new Object[]{});
			
			System.out.println("Finished asserting");
			
		} catch (Exception e) {
			System.out.println(e);
		} finally {
			System.out.println("Entering finally");
			try{
				conn.sendSync("exit 0");
			} catch (IOException e) {
				//System.out.println(e.getMessage());
				//ignore
			}
			FileUtils.deleteDirectory(tmpDir);
		}
		
		System.out.println("Exiting testStateAfterStartup");
		
	}
	
	@Test
	public void testUpdInsertFunction() throws IOException, KException {
		
		System.out.println("Entering testUpdInsertFunction");
		
		File tmpDir = new File(tmpPath);
		if (!tmpDir.exists()) {
			tmpDir.mkdir();
		} else {
			System.out.println("Deleting tmpDir="+tmpDir);
			FileUtils.deleteDirectory(tmpDir);
		}

		SimpleKdbConnection conn = null;

		try{
			KdbProcess.startKdbProcess(cmd, "", "");
			//On Linux we get connection refused if we don't wait 
			Thread.sleep(100L);
			System.out.println("Process started:" + Arrays.toString(cmd));
			
			conn = new SimpleKdbConnection(new c("localhost", Integer.parseInt(port)));
			System.out.println("Connection created");
			
			//insert a message
			conn.sendAsync(".u.upd", "mytable", new Object[]{"testSym", new Double(2.3)});
			
			//check .u.i - the log counter
			assertEquals(1L, conn.sendSync(".u.i"));
			
			//check msg was appended to the .u.L log
			//e.g. enlist (`upd;`mytable;(05:24:31.042943000;`testSym;2.3))
			Object[] msgs = (Object[])conn.sendSync("get .u.L");
			Object[] firstMsg = (Object[])msgs[0];
			assertEquals("upd", firstMsg[0]);
			assertEquals("mytable", firstMsg[1]);
			Object[] firstMsgData = (Object[]) firstMsg[2];
			@SuppressWarnings("unused")
			kx.c.Timespan kdbInsertTime = (kx.c.Timespan)firstMsgData[0];
			assertEquals("testSym", firstMsgData[1]);
			assertEquals(2.3, firstMsgData[2]);
			
			System.out.println("Finished asserting");
			
		} catch (Exception e) {
			System.out.println(e.getMessage());
		} finally {
			System.out.println("Entering finally");
			try{
				conn.sendSync("exit 0");
			} catch (IOException e) {
				//System.out.println(e.getMessage());
				//ignore
			}
			FileUtils.deleteDirectory(tmpDir);
		}
		
		System.out.println("Exiting testUpdInsertFunction");
		
	}
}

