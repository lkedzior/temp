package com.fxq;

import com.fxq.kdb.util.KdbProcess;

import java.io.IOException;

import static org.junit.Assert.fail;

//*Test will be run automatically by the maven plugin

public class RunQspecTest
{
    @org.junit.Test
    public void runQspec() throws IOException, InterruptedException {
        int exitValue = KdbProcess.runQspec();
        if(exitValue != 0) {fail("qspec failed, exitValue=" +exitValue);};
    }
}
