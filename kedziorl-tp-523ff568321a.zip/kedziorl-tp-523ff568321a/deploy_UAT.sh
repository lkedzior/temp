#!/usr/bin/env bash

VERSION=0.1-SNAPSHOT
app=tp

sh ../sdlc-utils/oldDeploy.sh fxq riverside1 target/$app-0.1-SNAPSHOT-dist.tar.gz $VERSION $app
