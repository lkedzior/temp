#!/usr/bin/env bash

echo -e "\n`date` Running $BASH_SOURCE"

stdoutLogFile=/home/fxq/stdout/highLowCalc.log
echo "stdoutLogFile=$stdoutLogFile"

echo "Starting $processId"
cd $(dirname $BASH_SOURCE)

export KDBCORELIB_DIR=./libs/KdbCoreLib
export QHOME=~/q/
export PATH=$PATH:$QHOME/l32
export QINIT=$KDBCORELIB_DIR/loadQLIBPATH.q
export QLIBPATH=$KDBCORELIB_DIR/core::$KDBCORELIB_DIR/core1

#"q highLowCalc.q -sourceTpHandle ::5010 -srcHdbHandle ::20402 -dstTpHandle ::5012 -p 5011 -o 0 -w 2048 -g 1"
q highLowCalc.q \
  -processId highLowCalc2060 \
  -sourceTpHandle ::20400 \
  -srcHdbHandle ::20402 \
  -dstTpHandle ::20600 \
  -trendDstTp ::20700 \
  -p 2060 -o 0 -w 2048 -g 1 \
  1>> $stdoutLogFile 2>&1 </dev/null &

echo "Exiting $BASH_SOURCE"
