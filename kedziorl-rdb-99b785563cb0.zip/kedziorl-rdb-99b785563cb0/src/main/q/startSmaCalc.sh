#!/usr/bin/env bash

echo -e "\n`date` Running $BASH_SOURCE"

stdoutLogFile=/home/fxq/stdout/smaCalc.log
echo "stdoutLogFile=$stdoutLogFile"

echo "Starting $processId"
cd $(dirname $BASH_SOURCE)

export KDBCORELIB_DIR=./libs/KdbCoreLib
export QHOME=~/q/
export PATH=$PATH:$QHOME/l32
export QINIT=$KDBCORELIB_DIR/loadQLIBPATH.q
export QLIBPATH=$KDBCORELIB_DIR/core::$KDBCORELIB_DIR/core1

q smaCalc.q \
  -processId pricesSmaCalc \
  -sourceTpHandle ::20200 \
  -dstTpHandle ::20300 \
  -p 2030 -o 0 -w 2048 -g 1 \
  1>> $stdoutLogFile 2>&1 </dev/null &

echo "Exiting $BASH_SOURCE"
