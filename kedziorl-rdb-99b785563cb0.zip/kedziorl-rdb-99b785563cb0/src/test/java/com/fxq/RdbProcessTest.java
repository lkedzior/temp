package com.fxq;

import com.fxq.kdb.connection.SimpleKdbConnection;
import com.fxq.kdb.util.KdbProcess;
import kx.c;
import org.apache.commons.io.FileUtils;

import java.io.File;
import java.io.IOException;
import java.util.Arrays;

import static java.lang.System.out;
import static org.junit.Assert.*;

public class RdbProcessTest
{
    String tmpPath="tmp";
    String tpPort="4999";
    String rdbPort="4998";

    String QLIBPATH = "target/KdbCoreLib/core::target/KdbCoreLib/core1";
    String QINIT = "target/KdbCoreLib/loadQLIBPATH.q";

    String[] tpCmd = new String[]{
            "q",
            "-p", tpPort};

    String[] rdbCmd = new String[]{
            "q", "src/main/q/rdb.q",
            "-tpProcessHandle", "::".concat(tpPort),
            "-hdbProcessHandle", "::dummyHdbHandle",
            "-hdbDir", tmpPath,
            "-p", rdbPort};

    @org.junit.Test
    public void testStateAfterStartup() throws IOException, c.KException {

        out.println("Entering testStateAfterStartup");

        File tmpDir = new File(tmpPath);
        if (!tmpDir.exists()) {
            tmpDir.mkdir();
        } else {
            out.println("Deleting tmpDir="+tmpDir);
            FileUtils.deleteDirectory(tmpDir);
        }

        SimpleKdbConnection tpConn = null;
        SimpleKdbConnection rdbConn = null;

        try{
            KdbProcess.startKdbProcess(tpCmd, "", "");
            //On Linux we get connection refused if we don't wait
            Thread.sleep(100L);
            out.println("Tp process started:" + Arrays.toString(tpCmd));

            tpConn = new SimpleKdbConnection(new c("localhost", Integer.parseInt(tpPort)));
            out.println("Tp connection created");

            tpConn.sendAsync(".u.i:1;");
            String tpLog = "\":src/test/testData/tpLog\"";
            tpConn.sendAsync(".u.L:`$".concat(tpLog));
            String subFunction = ".u.sub:{[x;y] enlist (`mytable;([]time:`timespan$();sym:`$();price:`float$()))}";
            tpConn.sendSync(subFunction);

            KdbProcess.startKdbProcess(rdbCmd, QINIT, QLIBPATH);
            Thread.sleep(100L);
            out.println("Rdb process started:" + Arrays.toString(tpCmd));

            rdbConn = new SimpleKdbConnection(new c("localhost", Integer.parseInt(rdbPort)));
            out.println("Rdb connection created");

            //check .u.t - list of tp tables
            assertArrayEquals(new String[]{"mytable"}, (String[])rdbConn.sendSync(".u.t"));

            //check an update in tpLog has been re-played correctly
            assertEquals(1L,rdbConn.sendSync("count mytable"));

            out.println("Finished asserting");

        } catch (Exception e) {
            out.println("ERROR: " + e);
            fail(e.toString());
        } finally {
            out.println("Entering finally");
            try {tpConn.sendSync("exit 0");} catch (Exception e) {out.println("Catching exception on exit, msg="+e.getMessage());};
            //rdbConn exit not needed, rdb should exit on tp restart
            FileUtils.deleteDirectory(tmpDir);
        }

        out.println("Exiting testStateAfterStartup");

    }
}
