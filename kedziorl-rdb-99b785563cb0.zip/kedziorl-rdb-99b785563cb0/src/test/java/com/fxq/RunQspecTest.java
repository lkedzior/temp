package com.fxq;

import com.fxq.kdb.util.KdbProcess;

import java.io.IOException;

import static org.junit.Assert.fail;

//*Test will be run automatically by the maven plugin

public class RunQspecTest
{
    @org.junit.Test
    public void runQspec() throws IOException, InterruptedException {
        int exitValue = KdbProcess.runQspec();

        //custom run
//        String QLIBPATH = "target/KdbCoreLib/core::target/KdbCoreLib/core1::target/qspecLib/init.q";
//        String QINIT = "target/KdbCoreLib/loadQLIBPATH.q";
//        String QSPEC_TESTS_DIR = "src/test/qspec/ohlcCalcProcessTest.q";
//        int exitValue = KdbProcess.runQspec(QLIBPATH, QINIT, QSPEC_TESTS_DIR);

        if(exitValue != 0) {fail("qspec failed, exitValue=" +exitValue);};
    }
}
