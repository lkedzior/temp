package com.fxq;

import com.fxq.kdb.util.KdbProcess;

import java.io.IOException;

/**
 * Created by Lukasz on 02/10/2017.
 */
//This main starts qspec in fail-hard mode. On error the qspec process will stop
//and you can, open a port, connect to it and interact with it to develop your test
//https://github.com/nugend/qspec/wiki/Test-Runner
//For example, if an error occurred inside the main body of a test, all the mocked values and fixtures loaded within the before block
//will be present and available and the assertions and other test helpers will be available to run with a simple copy and paste.
public class RunQspecFailHardMain {
    public static void main(String[] args) throws IOException, InterruptedException {
        System.out.println("[RunQspecFailHardMain]");
        System.out.println("Working directory = " + System.getProperty("user.dir"));

        //KdbProcess.runQspecFailHard();
        String QLIBPATH = "target/KdbCoreLib/core::target/KdbCoreLib/core1::target/qspecLib/init.q";
        String QINIT = "target/KdbCoreLib/loadQLIBPATH.q";

        String[] qspecCmd = new String[]{"q",
                "target/qspecLib/spec.q",
                "-q",
//                "src/test/qspec",
//                "src/test/qspec/closeCalcProcessTest.q",
                  "src/test/qspec/macdCalcProcessTest.q",
//                "src/test/qspec/highLowCalcProcessTest.q",
//                "src/test/qspec/ohlcCalcProcessTest.q",
//                "src/test/qspec/ohlcCalcProcessTest1.q",

                "--fail-hard"};
        Process p = KdbProcess.startKdbProcess(qspecCmd, QINIT, QLIBPATH);
        p.waitFor();
        int exitValue = p.exitValue();
        System.out.println("qspecProcess exitValue=" + exitValue);
    }
}
