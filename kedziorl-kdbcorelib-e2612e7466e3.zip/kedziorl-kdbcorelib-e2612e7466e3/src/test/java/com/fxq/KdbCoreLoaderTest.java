package com.fxq;

import com.fxq.kdb.connection.SimpleKdbConnection;
import com.fxq.kdb.util.KdbProcess;
import kx.c;

import java.util.Arrays;

import static java.lang.System.out;
import static org.junit.Assert.fail;

/**
 * Created by Lukasz on 24/08/2017.
 */
public class KdbCoreLoaderTest {
    String port="5001";

    String[] cmd = new String[]{
            KdbProcess.QCMD,
            //"-usersFile", "src/test/testData/security/users.csv",
            "-p", port};

    String QLIBPATH = "src/main/q/core"
            +"::src/main/q/core1";
            //+"::src/main/q/sec";
            //+"::src/main/q/usage";

    String QINIT = "src/main/q/loadQLIBPATH.q";

    @org.junit.Test
    public void checkLoader() {
        SimpleKdbConnection conn = null;

        try{
            KdbProcess.startKdbProcess(cmd,QINIT,QLIBPATH);
            Thread.sleep(100L);
            out.println("Kdb process started:" + Arrays.toString(cmd));

            conn = new SimpleKdbConnection(new c("localhost", Integer.parseInt(port)));
            out.println("Connection created");
        } catch (Exception e) {
            out.println("ERROR: " + e);
            fail(e.toString());
        } finally {
            out.println("Entering finally");
            try {conn.sendSync("exit 0");} catch(Exception e){out.println("Catching exception on exit, msg="+e.getMessage());};
        }
    }
}
