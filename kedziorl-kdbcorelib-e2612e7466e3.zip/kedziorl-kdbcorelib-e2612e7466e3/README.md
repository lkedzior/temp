q/core - independend libries
q/core1 - libraries that requires q/core to be loaded first